package com.java.hiber;

import java.sql.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Booking")
public class Booking {
	
	@Id
	@Column(name="BookId")
	private String bookid;
	
	@Column(name="RoomID")
	private String roomid;
	
	@Column(name="CustName")
	private String custname;
	
	@Column(name="City")
	private String city;
	
	@Column(name="BookDate")
	private Date bookdt;
	
	@Column(name="ChkInDate")
	private Date checkindt;
	
	@Column(name="ChkOutDate")
	private Date checkoutdt;

	public Booking() {
		// TODO Auto-generated constructor stub
	}

	public String getBookid() {
		return bookid;
	}

	public void setBookid(String bookid) {
		this.bookid = bookid;
	}

	public String getRoomid() {
		return roomid;
	}

	public void setRoomid(String roomid) {
		this.roomid = roomid;
	}

	public String getCustname() {
		return custname;
	}

	public void setCustname(String custname) {
		this.custname = custname;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public Date getBookdt() {
		return bookdt;
	}

	public void setBookdt(Date bookdt) {
		this.bookdt = bookdt;
	}

	public Date getCheckindt() {
		return checkindt;
	}

	public void setCheckindt(Date checkindt) {
		this.checkindt = checkindt;
	}

	public Date getCheckoutdt() {
		return checkoutdt;
	}

	public void setCheckoutdt(Date checkoutdt) {
		this.checkoutdt = checkoutdt;
	}
	

}
