package infinite.ClientComplaint;

import java.sql.SQLException;

import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

@Path("/complaint")
public class ComplaintServices {


@POST
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Path("/addComplaint")
public String addComplaint(Complaint complaint) throws ClassNotFoundException, SQLException {
return new complaintDAO().addComplaint(complaint);
}


@GET
@Produces(MediaType.APPLICATION_JSON)
public Complaint[] ShowAgent() throws ClassNotFoundException, SQLException {
	complaintDAO dao = new complaintDAO();
	return dao.ShowComplaint();
}

@GET
@Path("{complaintID}")
@Produces(MediaType.APPLICATION_JSON)
public Complaint ShowComplaint(@PathParam("complaintID") int ComplaintID) throws ClassNotFoundException, SQLException {
complaintDAO dao= new complaintDAO();
return dao.searchComplaint(ComplaintID);
}

@POST
@Path("/resolve")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public String resolve(Resolve resolve) throws ClassNotFoundException, SQLException {
	return new complaintDAO().resolve(resolve);
}

}