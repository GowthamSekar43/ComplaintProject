package infinite.Complaint;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.mysql.cj.protocol.Resultset;

public class complaintDAO {
Connection connection;
PreparedStatement pst;

public String addComplaint(Complaint complaint) throws ClassNotFoundException, SQLException {
	
	connection=ConnectionHelper.getConnection();
	String cmd="Insert into Complaint(ComplaintID,ComplaintType,CDescription,ComplaintDate,Severity)" 
			+ "values(?,?,?,?,?)";
	pst=connection.prepareStatement(cmd);
	pst.setInt(1, complaint.getComplaintId());
	pst.setString(2, complaint.getComplaintType());
	pst.setString(3, complaint.getcDescription());
	long d1=System.currentTimeMillis();
	java.sql.Date date=new java.sql.Date(d1);
	pst.setDate(4, date);
	pst.setString(5, complaint.getSeverity());
	
	
	pst.executeUpdate();
	
	return "Record Inserted";
	
}
public Complaint searchComplaint(int ComplaintID) throws ClassNotFoundException, SQLException {
	connection= ConnectionHelper.getConnection();
	String cmd="Select * from Complaint where ComplaintID=?";
	pst=connection.prepareStatement(cmd);
	pst.setInt(1, ComplaintID);
	ResultSet rs=pst.executeQuery();
	Complaint complaint=null;
	if(rs.next()) {
		complaint=new Complaint();
		complaint.setComplaintId(rs.getInt("ComplaintID"));
		complaint.setComplaintType(rs.getString("ComplaintType"));
		complaint.setcDescription(rs.getString("CDescription"));
		complaint.setComplaintDate(rs.getDate("ComplaintDate"));
		complaint.setSeverity(rs.getString("Severity"));
		complaint.setStatus(rs.getString("Status"));
	}
	return complaint;
}

public Complaint[] ShowComplaint() throws ClassNotFoundException, SQLException {
	connection=ConnectionHelper.getConnection();
	List<Complaint> complaintList = new ArrayList<Complaint>();
	String cmd = "select * from complaint" ;
	pst=connection.prepareStatement(cmd);
	ResultSet rs= pst.executeQuery();
	Complaint complaint = new Complaint();
	while(rs.next()) {
		complaint = new Complaint();
		complaint.setComplaintId(rs.getInt("ComplaintID"));
		complaint.setComplaintType(rs.getString("ComplaintType"));
		complaint.setcDescription(rs.getString("CDescription"));
		complaint.setComplaintDate(rs.getDate("ComplaintDate"));
		complaint.setSeverity(rs.getString("Severity"));
		complaint.setStatus(rs.getString("Status"));
		complaintList.add(complaint);
	}
	return complaintList.toArray(new Complaint[complaintList.size()]);
}


public String check(Complaint complaint) throws ClassNotFoundException, SQLException {
	 connection=ConnectionHelper.getConnection();
	String cmd="select resolvedate from resolve where ComplaintID=?";
    pst=connection.prepareStatement(cmd);
	pst.setInt(1,complaint.getComplaintId());
	ResultSet rs=pst.executeQuery();
  if(rs.next()) {
	Date resolvedDate=rs.getDate("resolvedate");
	long difference = resolvedDate.getTime() - complaint.getComplaintDate().getTime();
	double daysBetween = (difference / (1000*60*60*24));
	int days=(int)daysBetween;
	days++;
	if(resolvedDate.getTime()==complaint.getComplaintDate().getTime()) {
		return "green";
	}else if(days>=5) {
		return "pink";
	}else {
		return "yellow";
	}
  }
return null;
}
public String resolve(Resolve resolve) throws ClassNotFoundException, SQLException {
	Complaint complaint=searchComplaint(resolve.getComplaintId());
	if(complaint!=null) {
  connection=ConnectionHelper.getConnection();
		String cmd="insert into resolve(ComplaintID,ComplaintDate,ResolveDate,ResolvedBy,"
				+ "Comments) values(?,?,?,?,?)";
	     pst=connection.prepareStatement(cmd);
		pst.setInt(1, resolve.getComplaintId());
		pst.setDate(2, complaint.getComplaintDate());
		long d1=System.currentTimeMillis();
		java.sql.Date date=new java.sql.Date(d1);
		pst.setDate(3, date);
		pst.setString(4, resolve.getResolvedBy());
		pst.setString(5, resolve.getComments());
		pst.executeUpdate();
		
		cmd="update complaint set status='Resolved' where ComplaintID=?";
		PreparedStatement pst1=connection.prepareStatement(cmd);
		pst1.setInt(1, resolve.getComplaintId());
		pst1.executeUpdate();
		return "Record added";
		
	}
	return "Unknown Complaint ID";
}
}




