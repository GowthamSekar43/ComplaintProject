package infinite.Complaint;

import java.sql.Date;

public class Resolve {
private int complaintId;
private Date complaintDate;
private Date resolveDate;
private String resolvedBy;
private String comments;
public int getComplaintId() {
	return complaintId;
}
public void setComplaintId(int complaintId) {
	this.complaintId = complaintId;
}
public Date getComplaintDate() {
	return complaintDate;
}
public void setComplaintDate(Date complaintDate) {
	this.complaintDate = complaintDate;
}
public Date getResolveDate() {
	return resolveDate;
}
public void setResolveDate(Date resolveDate) {
	this.resolveDate = resolveDate;
}
public String getResolvedBy() {
	return resolvedBy;
}
public void setResolvedBy(String resolvedBy) {
	this.resolvedBy = resolvedBy;
}
public String getComments() {
	return comments;
}
public void setComments(String comments) {
	this.comments = comments;
}
@Override
public String toString() {
	return "Resolve [complaintId=" + complaintId + ", complaintDate=" + complaintDate + ", resolveDate=" + resolveDate
			+ ", resolvedBy=" + resolvedBy + ", comments=" + comments + "]";
}


}
